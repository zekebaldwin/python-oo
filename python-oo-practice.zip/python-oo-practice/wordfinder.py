"""Word Finder: finds random words from a dictionary."""


class WordFinder:
    ...
